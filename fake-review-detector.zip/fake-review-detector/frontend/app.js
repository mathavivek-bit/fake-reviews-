// If the page is opened directly from disk, talk to the backend on port 8080.
const API = location.protocol === 'file:' ? 'http://localhost:8080' : '';
const COLORS = { FAKE: '#d93025', SUSPICIOUS: '#e8a317', GENUINE: '#1e8e3e' };

const reviewEl = document.getElementById('review');
const ratingEl = document.getElementById('rating');
const resultEl = document.getElementById('result');
const historyEl = document.getElementById('history');

function escapeHtml(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

async function analyze() {
  const review = reviewEl.value.trim();
  const rating = Number(ratingEl.value);
  try {
    const res = await fetch(API + '/api/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ review, rating })
    });
    const data = await res.json();
    resultEl.classList.remove('hidden');
    if (data.error) { resultEl.innerHTML = '<b>' + escapeHtml(data.error) + '</b>'; return; }

    const pct = Math.round(data.score * 100);
    resultEl.innerHTML =
      '<span class="tag ' + data.verdict + '">' + data.verdict + '</span> ' +
      '<b>Fake likelihood: ' + pct + '%</b>' +
      '<div class="bar"><div class="fill" style="width:' + pct + '%;background:' + COLORS[data.verdict] + '"></div></div>' +
      '<small>Naive Bayes: ' + data.naiveBayes + ' | Rule score: ' + data.ruleScore + '</small>' +
      '<ul>' + data.reasons.map(r => '<li>' + escapeHtml(r) + '</li>').join('') + '</ul>';
    loadHistory();
  } catch (e) {
    resultEl.classList.remove('hidden');
    resultEl.innerHTML = '<b>Cannot reach the backend. Is it running on port 8080?</b>';
  }
}

async function loadHistory() {
  try {
    const items = await (await fetch(API + '/api/history')).json();
    historyEl.innerHTML = items.slice().reverse().map(x =>
      '<tr><td>' + escapeHtml(x.review.slice(0, 70)) + '</td>' +
      '<td><span class="tag ' + x.verdict + '">' + x.verdict + '</span></td>' +
      '<td>' + x.score + '%</td></tr>').join('');
  } catch (e) { /* backend offline */ }
}

document.getElementById('analyzeBtn').addEventListener('click', analyze);
document.querySelectorAll('.samples .link').forEach(b => b.addEventListener('click', () => {
  reviewEl.value = b.dataset.text;
  ratingEl.value = b.dataset.rating;
}));
loadHistory();
