import java.util.*;
import java.util.regex.*;

/** Detection engine: Naive Bayes + rule-based red flags. */
public class ReviewAnalyzer {

    public record Result(double score, String verdict, double nbProb, double ruleScore, List<String> reasons) {}

    private static final Set<String> HYPE_WORDS = Set.of("amazing", "perfect", "awesome", "fantastic", "best",
            "incredible", "excellent", "unbelievable", "flawless", "superb", "wonderful");
    private static final List<String> HYPE_PHRASES = List.of("must buy", "highly recommend", "five stars",
            "5 stars", "life changing", "life-changing", "best ever", "buy now", "you won't regret", "worth every penny");
    private static final Set<String> POS = Set.of("good", "great", "love", "amazing", "perfect", "excellent",
            "happy", "best", "awesome", "fantastic");
    private static final Set<String> NEG = Set.of("bad", "terrible", "awful", "worst", "broke", "broken", "poor",
            "disappointed", "useless", "waste", "stopped", "refund", "cheap");
    private static final Set<String> DETAIL = Set.of("battery", "screen", "size", "week", "weeks", "days", "day",
            "month", "months", "price", "shipping", "delivery", "packaging", "stopped", "but", "however",
            "although", "though", "returned", "fits", "sound", "lid", "cable", "charger", "support", "noise", "loud");
    private static final Pattern PROMO = Pattern.compile(
            "(https?://|www\\.|coupon|promo code|discount code|whatsapp|click (the )?link)", Pattern.CASE_INSENSITIVE);
    private static final Pattern ALLCAPS = Pattern.compile("\\b[A-Z]{3,}\\b");

    private final NaiveBayes nb = new NaiveBayes();
    private final List<String> previousReviews = new ArrayList<>();

    public ReviewAnalyzer() {
        for (String s : TrainingData.FAKE) nb.train(s, true);
        for (String s : TrainingData.REAL) nb.train(s, false);
    }

    public synchronized Result analyze(String text, int rating) {
        String lower = text.toLowerCase();
        List<String> toks = tokenize(lower);
        int n = toks.size();
        double rule = 0;
        List<String> reasons = new ArrayList<>();

        long hype = toks.stream().filter(HYPE_WORDS::contains).count();
        for (String p : HYPE_PHRASES) if (lower.contains(p)) hype += 2;
        if (hype >= 3) { rule += 0.25; reasons.add("Heavy hype/superlative language (" + hype + " signals)"); }

        long excl = text.chars().filter(c -> c == '!').count();
        if (excl >= 3) { rule += 0.15; reasons.add("Excessive exclamation marks (" + excl + ")"); }

        Matcher m = ALLCAPS.matcher(text);
        int caps = 0; while (m.find()) caps++;
        if (caps >= 3) { rule += 0.10; reasons.add("Many ALL-CAPS words (" + caps + ")"); }

        if (n < 12) { rule += 0.15; reasons.add("Very short, generic text (" + n + " words)"); }

        if (n >= 4 && toks.stream().noneMatch(t -> DETAIL.contains(t) || t.matches(".*\\d.*"))) {
            rule += 0.15; reasons.add("No concrete details (no numbers, durations or specific features)");
        }

        if (n >= 10) {
            double ttr = (double) new HashSet<>(toks).size() / n;
            if (ttr < 0.6) { rule += 0.10; reasons.add(String.format("Repetitive wording (diversity %.2f)", ttr)); }
        }

        if (PROMO.matcher(text).find()) { rule += 0.30; reasons.add("Promotional content (link / coupon / contact request)"); }

        long pos = toks.stream().filter(POS::contains).count();
        long neg = toks.stream().filter(NEG::contains).count();
        if ((rating >= 4 && neg >= 2 && pos == 0) || (rating <= 2 && pos >= 2 && neg == 0)) {
            rule += 0.15; reasons.add("Star rating contradicts the review sentiment");
        }

        Set<String> mine = new HashSet<>(toks);
        for (String prev : previousReviews) {
            Set<String> other = new HashSet<>(tokenize(prev));
            if (other.isEmpty() || mine.isEmpty()) continue;
            Set<String> inter = new HashSet<>(mine); inter.retainAll(other);
            Set<String> union = new HashSet<>(mine); union.addAll(other);
            if ((double) inter.size() / union.size() > 0.8) {
                rule += 0.30; reasons.add("Near-duplicate of a previously submitted review"); break;
            }
        }
        previousReviews.add(text);

        rule = Math.min(1.0, rule);
        double nbP = nb.probFake(text);
        double score = Math.min(1.0, 0.5 * nbP + 0.5 * rule);
        String verdict = score >= 0.60 ? "FAKE" : score >= 0.35 ? "SUSPICIOUS" : "GENUINE";
        if (reasons.isEmpty()) reasons.add("No red flags found");
        return new Result(score, verdict, nbP, rule, reasons);
    }

    public static List<String> tokenize(String s) {
        List<String> out = new ArrayList<>();
        Matcher m = Pattern.compile("[a-z0-9']+").matcher(s.toLowerCase());
        while (m.find()) out.add(m.group());
        return out;
    }
}
