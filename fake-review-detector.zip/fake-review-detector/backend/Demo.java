/** Console demo: prints the detector output for sample reviews (no browser needed). */
public class Demo {
    public static void main(String[] args) {
        ReviewAnalyzer analyzer = new ReviewAnalyzer();
        Object[][] samples = {
            {"Amazing product!!! Best ever, must buy now, highly recommend, five stars!!!", 5},
            {"Bought this blender 3 weeks ago. Works well for smoothies but it is loud and the lid is hard to remove.", 4},
            {"PERFECT PERFECT. Click the link www.cheap-deals.biz for a discount code, best product ever", 5},
            {"Battery lasts about two days. Screen is bright, however the case scratches easily and shipping took 9 days.", 3},
            {"Great product great price great seller", 5},
            {"Great product great price great seller", 5},
            {"Terrible waste of money, broke on day two and refund was refused. Worst purchase ever.", 5},
        };
        System.out.println("=== FAKE REVIEW DETECTOR - CONSOLE DEMO ===\n");
        int i = 1;
        for (Object[] s : samples) {
            String text = (String) s[0];
            int rating = (Integer) s[1];
            ReviewAnalyzer.Result r = analyzer.analyze(text, rating);
            System.out.printf("Review #%d (rating: %d stars)%n", i++, rating);
            System.out.println("  \"" + text + "\"");
            System.out.printf("  -> %-10s fake-likelihood: %3.0f%%  [NaiveBayes %.2f | Rules %.2f]%n",
                    r.verdict(), r.score() * 100, r.nbProb(), r.ruleScore());
            for (String why : r.reasons()) System.out.println("       * " + why);
            System.out.println();
        }
    }
}
