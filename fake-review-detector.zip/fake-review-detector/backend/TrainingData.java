/** Small labelled dataset used to train the Naive Bayes model. Add more rows to improve accuracy. */
public class TrainingData {
    public static final String[] FAKE = {
        "Amazing product!!! Best ever, highly recommend to everyone, five stars!",
        "Perfect perfect perfect. Must buy now, you won't regret it. Awesome!",
        "Best purchase of my life, absolutely incredible and flawless, buy now",
        "Excellent quality, fantastic seller, amazing amazing, highly recommend",
        "This changed my life! Unbelievable product, worth every penny, 5 stars",
        "Great product great price great seller will buy again, great great",
        "Wow just wow. Superb. Wonderful. Everyone must buy this right now",
        "Love it love it love it. Best best best. Highly recommended five stars",
        "Click the link for a discount code, amazing deal, best product ever",
        "Super awesome product, so perfect, I am very happy, amazing seller",
        "Fantastic!!! Totally recommend. Perfect in every way. Best ever",
        "Incredible item, five stars, perfect, will recommend to all my friends",
    };
    public static final String[] REAL = {
        "Bought this blender three weeks ago. Works well for smoothies but it is quite loud.",
        "The battery lasts about two days with heavy use. Screen is bright, though the case scratches easily.",
        "Delivery took 9 days and the box was damaged, but the item itself was fine and fits my desk.",
        "Stopped charging after two months. Support replied quickly and sent a replacement cable.",
        "Decent for the price. The zipper feels cheap and the strap is a bit short, however the size is right.",
        "I returned the first one because the lid did not seal. The second unit has been fine so far.",
        "Sound quality is good for 30 dollars, bass is weak though. Comfortable for an hour or so.",
        "Setup was easy but the app is clunky. Cooks rice evenly, cleaning takes a few minutes.",
        "Not what I expected. The color is darker than the photos and the fabric is thinner than described.",
        "Used it daily for a month. Handle loosened a little, but I tightened it and it holds well.",
        "It does the job. Shipping was slow, the instructions were confusing, but customer service helped.",
        "Compared with my old model this one is lighter and quieter, although the filter is pricey.",
    };
}
